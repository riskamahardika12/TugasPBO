package validasi.login;

import java.util.Scanner;

public class SistemValidasiLogin {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            String usernameBenar = "Riska";
            String passwordBenar = "Oktober2004";
            int percobaan = 0;
            boolean loginBerhasil = false;
            
            while (percobaan < 3) {
                System.out.print("Masukkan username: ");
                String username = scanner.nextLine();
                
                System.out.print("Masukkan password: ");
                String password = scanner.nextLine();
                
                if (username.equals(usernameBenar) && password.equals(passwordBenar)) {
                    System.out.println("Selamat datang, " + username + "!");
                    loginBerhasil = true;
                    break;
                } else {
                    percobaan++;
                    System.out.println("Username atau password salah! Percobaan: " + percobaan + "/3");
                }
            }
            
            if (!loginBerhasil) {
                System.out.println("Akun terkunci. Silakan coba lagi nanti.");
            }
        }
    }
}